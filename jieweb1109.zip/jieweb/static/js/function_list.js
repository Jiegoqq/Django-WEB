function handleButtonClick(buttonNumber) {
    alert('Button ' + buttonNumber + ' clicked!');
}